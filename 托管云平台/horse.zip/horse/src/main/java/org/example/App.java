package org.example;

/**
 * Hello world!
 *
 */
public class App 
{
    /**
     * 入口main方法
     */
    public static void main(String[] args) {

        new org.example.Horse(80,15, 10, 80, 80, 720,640);
    }
}
